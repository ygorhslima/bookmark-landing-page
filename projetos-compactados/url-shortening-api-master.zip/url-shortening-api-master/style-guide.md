# Front-end Style Guide

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 These are just the design sizes. Ensure content is responsive and meets WCAG requirements by testing the full range of screen sizes from 320px to large screens.

## Colors

### Primary

- Blue 400: hsl(180, 66%, 49%)
- Purple 950: hsl(257, 27%, 26%)

### Secondary

- Red 400: hsl(0, 87%, 67%)

### Neutral

- Gray 400: hsl(0, 0%, 75%)
- Gray 500: hsl(257, 7%, 63%)
- Gray 900: hsl(255, 11%, 22%)
- Gray 950: hsl(260, 8%, 14%)

## Typography

### Body Copy

- Font size: 18px

### Fonts

- Family: [Poppins](https://fonts.google.com/specimen/Poppins)
- Weights: 500, 700

## Icons

For the social icons, you can either use the SVGs provided or a font icon library. Some suggestions for font icon libraries can be found below:

- [Font Awesome](https://fontawesome.com)
- [IcoMoon](https://icomoon.io)
- [Ionicons](https://ionicons.com)

> 💎 [Upgrade to Pro](https://www.frontendmentor.io/pro?ref=style-guide) for design file access to see all design details and get hands-on experience using a professional workflow with tools like Figma.
