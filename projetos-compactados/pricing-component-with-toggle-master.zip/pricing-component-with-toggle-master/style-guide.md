# Front-end Style Guide

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 These are just the design sizes. Ensure content is responsive and meets WCAG requirements by testing the full range of screen sizes from 320px to large screens.

## Colors

### Primary

- Linear gradient: hsl(237, 73%, 79%) to hsl(238, 63%, 64%)

### Neutral

- Blue 50: hsl(240, 78%, 98%)
- Gray 650: hsl(233, 13%, 49%)
- Gray 700: hsl(232, 13%, 33%)

## Typography

### Body Copy

- Font size: 15px

### Font

- Family: [Montserrat](https://fonts.google.com/specimen/Montserrat)
- Weight: 700

> 💎 [Upgrade to Pro](https://www.frontendmentor.io/pro?ref=style-guide) for design file access to see all design details and get hands-on experience using a professional workflow with tools like Figma.
